<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $superpower = $conn->real_escape_string($_POST['superpower']);
    $birthYear = $conn->real_escape_string($_POST['birthYear']);
    $favoriteCharacter = $conn->real_escape_string($_POST['favoriteCharacter']);

    // Query to check if inputs match the database
    $sql = "SELECT * FROM quest WHERE superpower = '$superpower' AND birth_year = '$birthYear' AND favorite_character = '$favoriteCharacter'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Inputs match, redirect to test.html
        header("Location: reset-password_fac.html");
        exit(); // Ensure that no further code is executed after the redirect
    } else {
    
        echo "<script>alert('Inputs do not match the database.');</script>";
       
    }
}

// Close the database connection
$conn->close();
?>

