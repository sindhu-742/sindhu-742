<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$name = $conn->real_escape_string($_POST['name']);
    $superpower = $conn->real_escape_string($_POST['superpower']);
    $birthYear = $conn->real_escape_string($_POST['birthYear']);
    $favoriteCharacter = $conn->real_escape_string($_POST['favoriteCharacter']);

    // Insert user information into the 'users' table
    $sql = "INSERT INTO quest (name,superpower, birth_year, favorite_character) VALUES ('$name','$superpower', '$birthYear', '$favoriteCharacter')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to log&sign_faculty.html
        header("Location: log&sign_student.html");
        exit(); // Ensure that no further code is executed after the redirect
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

