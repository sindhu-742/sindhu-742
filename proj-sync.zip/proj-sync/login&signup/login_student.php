<?php

$conn = mysqli_connect('localhost','root','root', 'user');

$authenticated = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = strtolower($_POST['username']);
    $pass = $_POST['pass'];
    $query = "SELECT username,pass FROM student WHERE username = '$user'";
    $result = mysqli_query($conn, $query);
    //var_dump($result);
    $row = mysqli_fetch_row($result); // Fetch a row
    //var_dump($row);
    if ($row) {
        if ($pass == $row[1]) {
            $authenticated = true;
        } else {
           
            echo "<script>alert('Invalid password!')</script>";
          
            

        }
        
    } else {
        echo "<script>alert('User not found')</script>";
    }
}

if ($authenticated) {
    header("Location:/homes/stu_index.html");
    exit(); 
}
$conn->close();
?>
