<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $newPassword = $conn->real_escape_string($_POST['new_password']);
    $confirmPassword = $conn->real_escape_string($_POST['confirm_password']);

    // Check if the username exists in the 'user' table
    $checkUserQuery = "SELECT * FROM student WHERE username = '$username'";
    $result = $conn->query($checkUserQuery);

    if ($result->num_rows > 0) {
        // Username exists, proceed with password reset
        if ($newPassword === $confirmPassword) {
          

            // Update password in 'faculty' table
            $updateFacultyPasswordQuery = "UPDATE student SET pass = '$newPassword' WHERE username = '$username'";
            $conn->query($updateFacultyPasswordQuery);

            echo "<script>alert('Password updated successfully.');</script>";
        } else {
            echo "<script>alert('New password and confirm password do not match.');</script>";
        }
    } else {
        echo "<script>alert('Username not found.');</script>";
    }
}

// Close the database connection
$conn->close();
?>

