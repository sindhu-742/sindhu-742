
const profileLogo = document.getElementById("profile-logo");
const popupCard = document.getElementById("profile-popup");
const closeButton = document.getElementById("close-button");


profileLogo.addEventListener("click", () => {
    popupCard.style.display = "block";
});


/*window.addEventListener("click", (event) => {
    if (event.target === popupCard) {
        popupCard.style.display = "none";
    }
});
*/

closeButton.addEventListener("click", () => {
    popupCard.style.display = "none";
});

