<?php

$servername = "localhost";
$username = "root";
$password = "root";
$databse = "user";
 $conn = mysqli_connect($servername, $username, $password,$databse);

 $go = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $team_num = $_POST['team_number'];
$team_lead = $_POST['team_leader'];
$lead_id = $_POST['team_leader_id'];
$coder1 = $_POST['coder1'];
$cod1_id = $_POST['coder1_id'];
$coder2 = $_POST['coder2'];
$cod2_id = $_POST['coder2_id'];
$doc1 = $_POST['documentor1'];
$doc1_id = $_POST['documentor1_id'];
$doc2 = $_POST['documentor2'];
$doc2_id = $_POST['documentor2_id'];
$proj_name = $_POST['project_name'];
$proj_desc = $_POST['project_description'];
$prog = $_POST['progress'];

 $sql = "INSERT INTO team (team_number, team_leader, team_leader_id, coder1, coder1_id, coder2, coder2_id, documentor1, documentor1_id, documentor2, documentor2_id, project_name, project_description, progress) VALUES ('$team_num', '$team_lead', '$lead_id', '$coder1', '$cod1_id', '$coder2', '$cod2_id', '$doc1', '$doc1_id', '$doc2', '$doc2_id', '$proj_name', '$proj_desc', '$prog')";
 if ($conn->query($sql) === TRUE) {
 $go = true;
 } else {
    echo "error creating student:" . $conn->error . "<br>";
 }
 }
 
if ($go) {
    header("Location:index.html");
    exit(); 
}
$conn->close();
 ?>
