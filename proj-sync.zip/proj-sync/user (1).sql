-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 27, 2024 at 08:35 PM
-- Server version: 10.6.12-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `conf_passwd` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`username`, `email`, `pass`, `conf_passwd`) VALUES
('kakashi', '7777@naruto.com', 'Naruto@7', '1234567890'),
('jaanu', 'o190352@rguktong.ac.in', 'Laptop@7', 'Biryani@352'),
('jaanu', 'o190352@rguktong.ac.in', 'Laptop@7', 'Biryani@352'),
('jaanu', 'o190352@rguktong.ac.in', 'Laptop@7', 'Biryani@352'),
('jayanth', 'o190344@rguktong.ac.in', 'Universe@7', 'Projsyncpassword@7'),
('jay', 'o19@rguktong.ac.in', 'Jayanthkumar@7', 'Jayanthkumar@7'),
('naruto', 'o19@rguktong.ac.in', 'Sasuke@7', 'Hinatapassword@7'),
('kakashi', 'o190344@rguktong.ac.in', 'Naruto@7', 'Sharinganpassword@7'),
('gojo satouru', 'o190344@rguktong.ac.in', 'Sixeyes@7', 'Sixeyes@7'),
('naruto uzumaki', 'o190344@rguktong.ac.in', 'Naruto@7', 'Naruto@7'),
('uyhcf', 'sddc@sdfcsd', 's', 'fczd'),
('eren yeager', 'o190344@rguktong.ac.in', 'Tatake@7', 'Tatake@7'),
('itachi', 'o190344@rguktong.ac.in', 'Sasuke@7', 'Sasuke@7'),
('sdjknm', 'o19jabs@rguktong.ac.in', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE `password_reset` (
  `email` varchar(250) NOT NULL,
  `key` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_temp`
--

CREATE TABLE `password_reset_temp` (
  `email` varchar(250) NOT NULL,
  `key` varchar(250) NOT NULL,
  `expDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quest`
--

CREATE TABLE `quest` (
  `name` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `superpower` varchar(255) NOT NULL,
  `birth_year` varchar(255) NOT NULL,
  `favorite_character` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quest`
--

INSERT INTO `quest` (`name`, `id`, `superpower`, `birth_year`, `favorite_character`) VALUES
('', 1, 'teleportation', '3000', 'spiderman'),
('', 2, 'lightspeed', '2000', 'naruto'),
('', 3, 'omnipotent', '0', 'narutoluffy'),
('jay', 4, 'magic', '200', 'rimuru'),
('asta', 5, 'negativemagic', '100', 'lilly'),
('eren', 6, 'attacktitan', '2000', 'mikasa'),
('satish', 7, 'statue', '2004', 'virat');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `conf_passwd` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`username`, `email`, `pass`, `conf_passwd`) VALUES
('jayanth', 'o190344@rguktong.ac.in', '987654321', '0987654321'),
('harish', 'harish@gmail.com', 'Harish@123', 'Harish@123'),
('harish', 'harish@gmail.com', 'Harish@123', 'Harish@123'),
('luffy', 'o19@rguktong.ac.in', 'Onepiece@7', 'Onepiece@7'),
('obito', 'o190344@rguktong.ac.in', 'Rinpassword@7', 'Rinpassword@7'),
('obito', 'o190344@rguktong.ac.in', 'Rinpassword@7', 'Rinpassword@7'),
('obito', 'o190344@rguktong.ac.in', 'Rinpassword@7', 'Rinpassword@7'),
('eren', 'o190344@rguktong.ac.in', 'Mikasa@7', 'Freedom@7'),
('obito uchiha', 'o190344@rguktong.ac.in', 'Oneeye@7', 'Oneeye@7'),
('jayanth', 'o190344@rguktong.ac.in', 'Password@7', 'Password@7'),
('Archu', 'o191054@rguktong.ac.in', 'Archana@5', 'Archana@5');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `task_name` varchar(255) NOT NULL,
  `task_completed` tinyint(1) NOT NULL DEFAULT 0,
  `task_timer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `team_number` int(15) NOT NULL,
  `team_leader` text NOT NULL,
  `team_leader_id` varchar(15) NOT NULL,
  `coder1` text NOT NULL,
  `coder1_id` varchar(15) NOT NULL,
  `coder2` text NOT NULL,
  `coder2_id` varchar(15) NOT NULL,
  `documentor1` text NOT NULL,
  `documentor1_id` varchar(15) NOT NULL,
  `documentor2` text NOT NULL,
  `documentor2_id` varchar(15) NOT NULL,
  `project_name` varchar(20) NOT NULL,
  `project_description` varchar(200) NOT NULL,
  `progress` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`team_number`, `team_leader`, `team_leader_id`, `coder1`, `coder1_id`, `coder2`, `coder2_id`, `documentor1`, `documentor1_id`, `documentor2`, `documentor2_id`, `project_name`, `project_description`, `progress`) VALUES
(5, 'JAYANTH KUMAR', 'o190344', 'LOHITH', 'o190817', 'ARCHANA', 'o190041', 'SINDHU', 'o190742', 'JAYAPRIYA', 'o190756', 'PROJ-SYNC', 'It is difficult to remember and check the details of every team andsion.\r\n', '50%'),
(19, 'chiranjeevi', 'o190000', 'pawan kalyan', 'o198001', 'allu arjiun', 'o190344', 'ram charan', 'o199002', 'varun tej', 'o193456', 'mega family', '\r\nThe family is colloquially known as Mega family in reference to the moniker of Chiranjeevi—Mega Star. This family is one of prominent family in India considering film industry sector.', '99%'),
(18, 'MONKEY D LUFFY', 'o190344', 'RORONOA ZORO', 'o199999', 'VINSMOKE SANJI', 'o198888', 'CAT BURGLAR NAMI', 'o197777', 'GOD D USSOP', 'o196666', 'STARW HAT PIRATES', 'The Straw Hat Pirates, also known as the Mugiwara Pirates, Straw Hat Crew or simply the Straw Hats, are a very infamous and powerful pirate crew that originated from the East Blue.', '70%'),
(1, 'obito uchiha', 'o190344', 'pain', 'o191111', 'itachi uchiha', 'o192222', 'kisame', 'o193333', 'deidara', 'o194444', 'akatsuki', 'akatsuki is a organization of villians whose goal is to capture all jinchurikis and revive ten tails to go into the infinity tsukuyomi', '99%'),
(1, 'obito uchiha', 'o190344', 'pain', 'o191111', 'itachi uchiha', 'o192222', 'kisame', 'o193333', 'deidara', 'o194444', 'akatsuki', 'akatsuki is a organization of villians whose goal is to capture all jinchurikis and revive ten tails to go into the infinity tsukuyomi', '99%'),
(15, 'ichigo kurosaki', 'o190344', 'sosuke aizen', 'o197777', 'zaraki kenpachi', 'o191010', 'inoue orihime', 'o198080', 'rukia kuchiki', 'o190101', 'soul society', 'it is an another dimension consist of only souls but it has shinigami who has lot of powers which can destroy world', '77%'),
(19, 'sdfghj', 'o190817', 'sdfghj', 'o190931', 'dfghj', 'o190940', 'asdfghj', 'o190932', 'asdf', 'o190179', 'wdtfyguio', 'sdfguyiojk;l,mnbvcfdxes\r\n', '90%'),
(6, 'A Dinesh', 'o190781', 'K Sivaram', 'o190931', 'Ch Sowmya', 'o190248', 'A Abhinaya', 'o190746', 'M Shubashini', 'o191014', 'CCRR', 'this project is elated to somewhat...\r\n', '10%');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quest`
--
ALTER TABLE `quest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quest`
--
ALTER TABLE `quest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
