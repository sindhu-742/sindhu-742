  const toggleButton = document.getElementById('toggleButton');
        const hiddenData = document.getElementById('hiddenData');

        // Add a click event listener to the button
        toggleButton.addEventListener('click', function() {
            // Toggle the visibility of the hidden data
            if (hiddenData.style.display === 'none') {
                hiddenData.style.display = 'block';
            } else {
                hiddenData.style.display = 'none';
            }
        });
