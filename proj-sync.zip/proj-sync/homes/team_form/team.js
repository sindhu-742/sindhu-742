
        function validateForm() {
            var teamNumber = document.getElementById("team_number").value;
            var teamLeader = document.getElementById("team_leader").value;
            var coder1 = document.getElementById("coder1").value;
            var coder2 = document.getElementById("coder2").value;
            var documentor1 = document.getElementById("documentor1").value;
            var documentor2 = document.getElementById("documentor2").value;
            var teamLeaderID = document.getElementById("team_leader_id").value;
            var coder1ID = document.getElementById("coder1_id").value;
            var coder2ID = document.getElementById("coder2_id").value;
            var documentor1ID = document.getElementById("documentor1_id").value;
            var documentor2ID = document.getElementById("documentor2_id").value;
            var progress = document.getElementById("progress").value;

            var teamNumberPattern = /^\d{1,2}$/;
            var namePattern = /^[a-zA-Z\s]+$/;
            var idPattern = /^o19\d{4}$/;
            var progressPattern = /^\d{1,2}\%$/;

 
            if (!teamNumberPattern.test(teamNumber) || parseInt(teamNumber) >= 20) {
                alert("Team number must be a number under 20.");
                return false;
            }
            if (!namePattern.test(teamLeader) || !namePattern.test(coder1) || !namePattern.test(coder2) || !namePattern.test(documentor1) || !namePattern.test(documentor2)) {
                alert("Team leader, coders, and documentors should contain only letters (no numbers or special characters).");
                return false;
            }
            if (!idPattern.test(teamLeaderID) || !idPattern.test(coder1ID) || !idPattern.test(coder2ID) || !idPattern.test(documentor1ID) || !idPattern.test(documentor2ID)) {
                alert("ID must start with 'o19' and consist of 7 letters and numbers.");
                return false;
            }
            if (!progressPattern.test(progress)) {
                alert("Progress must be in the format of 2 digits followed by '%' (e.g., '50%').");
                return false;
            }

      
            return true;
        }
