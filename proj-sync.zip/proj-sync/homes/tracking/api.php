<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "user"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve tasks for a specific user
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['user_id'])) {
        $user_id = $_GET['user_id'];
        $result = $conn->query("SELECT * FROM tasks WHERE user_id = $user_id");
        $tasks = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($tasks);
    } else {
        echo "Invalid request";
    }
}

// Save tasks for a specific user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $user_id = $data['user_id'];
    $tasks = $data['tasks'];

    // Delete existing tasks for the user
    $conn->query("DELETE FROM tasks WHERE user_id = $user_id");

    // Insert new tasks
    foreach ($tasks as $task) {
        $task_name = $conn->real_escape_string($task['taskText']);
        $task_completed = $task['completed'] ? 1 : 0;
        $task_timer = $task['taskTimer'];
        $conn->query("INSERT INTO tasks (user_id, task_name, task_completed, task_timer) VALUES ($user_id, '$task_name', $task_completed, $task_timer)");
    }

    echo "Tasks updated successfully";
}

// Close the database connection
$conn->close();
?>

