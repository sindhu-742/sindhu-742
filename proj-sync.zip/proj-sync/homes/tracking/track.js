var taskInput = document.querySelector(".task-input");
        var taskDaysInput = document.querySelector(".task-days-input");
        var taskHoursInput = document.querySelector(".task-hours-input");
        var taskMinutesInput = document.querySelector(".task-minutes-input");
        var addTaskBtn = document.querySelector(".submit-task");
        var taskList = document.querySelector(".task-list");

        addTaskBtn.addEventListener("click", function () {
            addTask();
        });

        function addTask() {
            var li = document.createElement("li");
            li.classList.add("task-list-item");

            var checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            li.appendChild(checkbox);

            var taskText = document.createElement("span");
            taskText.textContent = taskInput.value;
            li.appendChild(taskText);

            var days = parseInt(taskDaysInput.value) || 0;
            var hours = parseInt(taskHoursInput.value) || 0;
            var minutes = parseInt(taskMinutesInput.value) || 0;
            var totalSeconds = (days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60);

            var buttonDiv = document.createElement("div");

            var deleteBtn = document.createElement("span");
            deleteBtn.classList.add("delete-btn");
            deleteBtn.addEventListener("click", function () {
                li.remove();
            });
            buttonDiv.appendChild(deleteBtn);

            taskList.appendChild(li);
            taskInput.value = "";
            taskDaysInput.value = "";
            taskHoursInput.value = "";
            taskMinutesInput.value = "";

            var editBtn = document.createElement("span");
            editBtn.classList.add("edit-btn");
            editBtn.addEventListener("click", function () {
                enableEditing(taskText, editBtn);
            });
            buttonDiv.appendChild(editBtn);

            li.appendChild(buttonDiv);

            var saveBtn = document.createElement("span");
            saveBtn.classList.add("save-btn");
            saveBtn.style.display = "none";
            saveBtn.addEventListener("click", function () {
                disableEditing(taskText, editBtn, saveBtn);
            });
            buttonDiv.appendChild(saveBtn);

            // Add timer
            var timerDiv = document.createElement("div");
            timerDiv.classList.add("timer");
            li.appendChild(timerDiv);

            startTimer(li, totalSeconds, checkbox);
        }

        function enableEditing(taskText, editBtn) {
            taskText.contentEditable = true;
            taskText.style.border = "1px solid #ccc";
            editBtn.style.display = "none";
            taskText.focus();
            var saveBtn = editBtn.nextSibling;
            saveBtn.style.display = "inline-block";
        }

        function disableEditing(taskText, editBtn, saveBtn) {
            taskText.contentEditable = false;
            taskText.style.border = "none";
            saveBtn.style.display = "none";
            editBtn.style.display = "inline-block";
        }

        function startTimer(taskElement, totalSeconds, checkbox) {
            var timerDiv = taskElement.querySelector(".timer");
            var daysSpan = document.createElement("span");
            var hoursSpan = document.createElement("span");
            var minutesSpan = document.createElement("span");
            var secondsSpan = document.createElement("span");

            var timerInterval = setInterval(function () {
                if (!checkbox.checked) {
                    var days = Math.floor(totalSeconds / (60 * 60 * 24));
                    var hours = Math.floor((totalSeconds % (60 * 60 * 24)) / (60 * 60));
                    var minutes = Math.floor((totalSeconds % (60 * 60)) / 60);
                    var seconds = totalSeconds % 60;

                    daysSpan.textContent = days + " days ";
                    hoursSpan.textContent = hours + " hours ";
                    minutesSpan.textContent = minutes + " minutes ";
                    secondsSpan.textContent = seconds + " seconds ";

                    if (totalSeconds <= 0) {
                        clearInterval(timerInterval);
                        daysSpan.textContent = "";
                        hoursSpan.textContent = "";
                        minutesSpan.textContent = "";
                        secondsSpan.textContent = "Time's up!";
                        alert("YOU HAVE FAILED TO COMPLETE THE TASK IN TIME");
                    } else {
                        totalSeconds--;
                    }
                } else {
                    clearInterval(timerInterval);
                    timerDiv.textContent = "completed";
                    alert("Task completed!");
                }
            }, 1000);

            timerDiv.appendChild(daysSpan);
            timerDiv.appendChild(hoursSpan);
            timerDiv.appendChild(minutesSpan);
            timerDiv.appendChild(secondsSpan);
        }


function updateProgressBar() {
    const tasks = document.querySelectorAll(".task-list-item input[type='checkbox']");
    const completedTasks = [...tasks].filter(task => task.checked);
    const progress = (completedTasks.length / tasks.length) * 100;
    const progressBar = document.querySelector(".progress-bar");
    const percentageText = document.querySelector(".percentage");


    progressBar.style.width = progress + "%";

 
    percentageText.textContent = Math.round(progress) + "%";
    percentageText.style.opacity = 1; 

    if (progress === 100) {
      
        alert("All tasks completed!");
    }
}


document.addEventListener("change", function (event) {
    if (event.target && event.target.type === "checkbox") {
        updateProgressBar();
        if (event.target.checked) {
            const taskText = event.target.nextSibling.nextSibling;
            taskText.style.textDecoration = "line-through";
            taskText.style.color = "rgba(255, 255, 255, 0.5)";
        } else {
            const taskText = event.target.nextSibling.nextSibling;
            taskText.style.textDecoration = "none";
            taskText.style.color = "#fff";
        }
    }
});

