<?php

//database connection
$servername = "localhost";
$username = "root";
$password = "root";
$databse = "user";
 $conn = mysqli_connect($servername, $username, $password,$databse);
//code for cards
  $sql="select *from team";
  $row=mysqli_query($conn,$sql);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Simple landing page</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="vendors/owl-carousel/css/owl.carousel.min.css">
  <!-- <link rel="stylesheet" href="vendors/owl-carousel/css/owl.theme.default.css">              -->
  <link rel="stylesheet" href="vendors/aos/css/aos.css">
  <link rel="stylesheet" href="style.min.css">
  <link rel="stylesheet" type="text/css" href="flip4.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <script>
    function fun2(){
    document.getElementById('div2').style.display='none';
    document.getElementById('div1').style.display='block';
  
  }
  </script>
</head>
<body id="body" data-spy="scroll" data-target=".navbar" data-offset="100">
  <header id="header-section">
    <nav class="navbar navbar-expand-lg pl-3 pl-sm-0" id="navbar">
    <div class="container">
      <div class="navbar-brand-wrapper d-flex w-100">
        <h3>Proj-Sync</h3>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="mdi mdi-menu navbar-toggler-icon"></span>
        </button> 
      </div>
      <div class="collapse navbar-collapse navbar-menu-wrapper" id="navbarSupportedContent">
        <ul class="navbar-nav align-items-lg-center align-items-start ml-auto">
          <li class="d-flex align-items-center justify-content-between pl-4 pl-lg-0">
            <div class="navbar-collapse-logo">
              <img src="images/Group2.svg" alt="">
            </div>
            <button class="navbar-toggler close-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="mdi mdi-close navbar-toggler-icon pl-5"></span>
            </button>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#header-section">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#features-section">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#feedback-section">Blog</a>  
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact-section">Others</a>
          </li>
         <li class="nav-item">
            <a class="nav-link" href="projects/projects.html">Senior Projects</a>  
          </li>
          <li class="nav-item btn-contact-us pl-4 pl-lg-0">
            <button class="btn btn-info" data-toggle="modal" data-target="#exampleModal">Contact Us</button>
          </li>
        </ul>
      </div>
    </div> 
    </nav>   
  </header>
  <div class="banner" >
    <div class="container">
      <h1 class="font-weight-semibold">Proj-Sync<br>Collective Progress Tracker</h1>
      <h6 class="font-weight-normal text-muted pb-3">It is difficult to remember and check the details of every team and their project progression.Also for teams who are doing their projects are will to know how much progression they are making and whether they are completing the work in time or not. So our project solves the all the above problems.</h6>
      <div>
        <button  class="btn btn-opacity-light mr-1" id="toggleButton" >Get started</button>
      <img src="images/Group171.svg" alt="" class="img-fluid">
    </div>
  </div>


  <section>
            
    <div class="row">
      <div class="div1" id="div1">
        <div class="containerl">
                     <?php
                      foreach ($row as $data) {
                        // code...

                        include('card.php');

                      }

                     ?>


        </div>
      </div>
      <div class="div2" id="div2">
        <div onclick="fun2()"><i  class='bx bx-x'></i></div>
        <div class="div3">
        <div class="div4" id="div4">
        <label style="font-family: sans-serif; color: orangered; font-weight: 1000; text-decoration: underline;">TeamLeader:</label>
                <label id="id1"><?php echo$data['team_leader']?>[<?php echo$data['team_leader_id']?>]</label>
                <label style="font-family: sans-serif; color: orangered; font-weight: 1000; text-decoration: underline;">Coders:</label><br>
                <label id="id2"><?php echo$data['coder1']?>[<?php echo$data['coder1_id']?>]</label>
                <label id="id2"><?php echo$data['coder2']?>[<?php echo$data['coder2_id']?>]</label>
                <label id="id4">Documenters:</label><br>
                <label id="id3"><?php echo$data['documentor1']?>[<?php echo$data['documentor1_id']?>]</label>
                <label id="id3"><?php echo$data['documentor2']?>[<?php echo$data['documentor2_id']?>]</label>
              </div>    
        <div class="div5" id="div5">

    </div>    
        </div>
      </div>
    </div>
  </section>

 <div class="content-wrapper">
    <div class="container">
      <section class="features-overview" id="features-section" >
        <div class="content-header">
          <h2>How does it works</h2>
          <h6 class="section-subtitle text-muted">One theme that serves as an easy-to-use and also track your projects easily.</h6>
        </div>
        <div class="d-md-flex justify-content-between">
          <div class="grid-margin d-flex justify-content-start">
            <div class="features-width">
              <img src="images/Group12.svg" alt="" class="img-icons">
              <h5 class="py-3">Team Details</h5>
              <p class="text-muted">It gives details of your team and what roles they are playing in that project..</p>
              <a href="#"><p class="readmore-link">Readmore</p></a>  
            </div>
          </div>
          <div class="grid-margin d-flex justify-content-center">
            <div class="features-width">
              <img src="images/Group7.svg" alt="" class="img-icons">
              <h5 class="py-3">Previous projects<br>and Information</h5>
              <p class="text-muted">Here we provide the some information to choose a project based on previous projects. So you can get some knowledge about the project.</p>
              <a href="#"><p class="readmore-link">Readmore</p></a>
            </div>
          </div>
          <div class="grid-margin d-flex justify-content-end">
            <div class="features-width">
              <img src="images/Group5.svg" alt="" class="img-icons">
              <h5 class="py-3">Alerts and<br>Messages</h5>
              <p class="text-muted">We alerts you whenever you are not done the work. Also you can categorize the project into the parts. Based on that we alert you. </p>
              <a href="#"><p class="readmore-link">Readmore</p></a>
            </div>
          </div>
        </div>
      </section>     
      <section class="customer-feedback" id="feedback-section">
        <div class="row">
          <div class="col-12 text-center pb-5">
            <h2>Team members</h2>
            <h6 class="section-subtitle text-muted m-0">These are our hardworking team members who made this project possible.</h6>
          </div>
          <div class="owl-carousel owl-theme grid-margin">
              <div class="card customer-cards">
                <div class="card-body">
                  <div class="text-center">
                    <img src="images/-face2.jpg" width="89" height="89" alt="" class="img-customer">
                    <p class="m-0 py-3 text-muted">IIIT-ONGOLE B.TECH 3RD YEAR STUDENT STUDYING CSE.</p>
                    <div class="content-divider m-auto"></div>
                    <h6 class="card-title pt-3">JAYANTH KUMAR</h6>
                    <h6 class="customer-designation text-muted m-0">TEAM LEADER</h6>
                  </div>
                </div>
              </div>
              <div class="card customer-cards">
                <div class="card-body">
                  <div class="text-center">
                    <img src="images/-face3.jpg" width="89" height="89" alt="" class="img-customer">
                    <p class="m-0 py-3 text-muted">IIIT-ONGOLE B.TECH 3RD YEAR STUDENT STUDYING CSE.</p>
                    <div class="content-divider m-auto"></div>
                    <h6 class="card-title pt-3">LOHITH</h6>
                    <h6 class="customer-designation text-muted m-0">TEAM CODER</h6>
                  </div>
                </div>
              </div>
              <div class="card customer-cards">
                <div class="card-body">
                  <div class="text-center">
                    <img src="images/-face20.jpg" width="89" height="89" alt="" class="img-customer">
                    <p class="m-0 py-3 text-muted">IIIT-ONGOLE B.TECH 3RD YEAR STUDENT STUDYING CSE.</p>
                    <div class="content-divider m-auto"></div>
                    <h6 class="card-title pt-3">ARCHANA</h6>
                    <h6 class="customer-designation text-muted m-0">TEAM CODER</h6>
                  </div>
                </div>
              </div>
              <div class="card customer-cards">
                <div class="card-body">
                  <div class="text-center">
                    <img src="images/-face15.jpg" width="89" height="89" alt="" class="img-customer">
                    <p class="m-0 py-3 text-muted">IIIT-ONGOLE B.TECH 3RD YEAR STUDENT STUDYING CSE.</p>
                    <div class="content-divider m-auto"></div>
                    <h6 class="card-title pt-3">SINDHU</h6>
                    <h6 class="customer-designation text-muted m-0">TEAM DOCUMENTOR</h6>
                  </div>
                </div>
              </div>
              <div class="card customer-cards">
                <div class="card-body">
                  <div class="text-center">
                    <img src="images/-face16.jpg" width="89" height="89" alt="" class="img-customer">
                    <p class="m-0 py-3 text-muted">IIIT-ONGOLE B.TECH 3RD YEAR STUDENT STUDYING CSE.</p>
                    <div class="content-divider m-auto"></div>
                    <h6 class="card-title pt-3">JAYAPRIYA</h6>
                    <h6 class="customer-designation text-muted m-0">TEAM DOCUMENTOR</h6>
                  </div>
                </div>
              </div>
          
      </section>

      <section class="contact-us" id="contact-section">
        <div class="contact-us-bgimage grid-margin" >
          <div class="pb-4">
            <h4 class="px-3 px-md-0 m-0" data-aos="fade-down">Do you have any projects?</h4>
            <h4 class="pt-1" data-aos="fade-down">Contact us</h4>
          </div>
          <div data-aos="fade-up">
            <button class="btn btn-rounded btn-outline-danger">Contact us</button>
          </div>          
        </div>
      </section>
      <section class="contact-details" id="contact-details-section">
        <div class="row text-center text-md-left">
          <div class="col-12 col-md-6 col-lg-4 grid-margin">
            <h4>Proj-Sync</h4>
            <div class="pt-2">
              <p class="text-muted m-0">example@gmail.com</p>
              <p class="text-muted m-0">1234567890</p>
            </div>         
          </div>
          <div class="col-12 col-md-6 col-lg-4 grid-margin">
            <h5 class="pb-2">Our Guidelines</h5>
            <a href="#"><p class="m-0 pb-2">Terms</p></a>   
            <a href="#" ><p class="m-0 pt-1 pb-2">Privacy policy</p></a> 
            <a href="#"><p class="m-0 pt-1 pb-2">Cookie Policy</p></a> 
            <a href="#"><p class="m-0 pt-1">Discover</p></a> 
          </div>
          <div class="col-12 col-md-6 col-lg-4 grid-margin">
              <h5 class="pb-2">Our address</h5>
              <p class="text-muted">518 Schmeler Neck<br>Bartlett. Illinois</p>
              <div class="d-flex justify-content-center justify-content-md-start">
                <a href="#"><span class="mdi mdi-facebook"></span></a>
                <a href="#"><span class="mdi mdi-twitter"></span></a>
                <a href="#"><span class="mdi mdi-instagram"></span></a>
                <a href="#"><span class="mdi mdi-linkedin"></span></a>
              </div>
          </div>
        </div>  
      </section>
      <footer class="border-top" style="background-color: skyblue; height: 10vh; width: 100%; color: white;">
        <p class="text-center text-muted pt-4">Copyright © Proj-Sync<a href="https://www.bootstrapdash.com/" class="px-1">Team-5</a>All rights reserved.</p>
      </footer>
      <!-- Modal for Contact - us Button -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title" id="exampleModalLabel">Contact Us</h4>
            </div>
            <div class="modal-body">
              <form>
                <div class="form-group">
                  <label for="Name">Name</label>
                  <input type="text" class="form-control" id="Name" placeholder="Name">
                </div>
                <div class="form-group">
                  <label for="Email">Email</label>
                  <input type="email" class="form-control" id="Email-1" placeholder="Email">
                </div>
                <div class="form-group">
                  <label for="Message">Message</label>
                  <textarea class="form-control" id="Message" placeholder="Enter your Message"></textarea>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div> 
  </div>
  <script src="vendors/jquery/jquery.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.min.js"></script>
  <script src="vendors/owl-carousel/js/owl.carousel.min.js"></script>
  <script src="vendors/aos/js/aos.js"></script>
  <script src="landingpage.js"></script>
</body>
</html>
