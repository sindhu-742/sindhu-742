<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

  <script>
    function fun1(){
      document.getElementById('div1').style.display='none';
      document.getElementById('div2').style.display='block';
    }
  </script>
</head>
<body>
		<div class="containerl">
            <div class="card">
              <div class="front" style="font-weight: 1000;">
                <label>TEAM</label><br>
                <label><?php echo$data['team_number']?></label><br>
                <label><?php echo$data['project_name']?></label>

              </div>
              <div class="back"> 
                <label style="font-family: sans-serif; color: orangered; font-weight: 1000; text-decoration: underline;">TeamLeader:</label>
                <label id="id1"><?php echo$data['team_leader']?>[<?php echo$data['team_leader_id']?>]</label>
                <label style="font-family: sans-serif; color: orangered; font-weight: 1000; text-decoration: underline;">Coders:</label><br>
                <label id="id2"><?php echo$data['coder1']?>[<?php echo$data['coder1_id']?>]</label>
                <label id="id2"><?php echo$data['coder2']?>[<?php echo$data['coder2_id']?>]</label>
                <label id="id4">Documenters:</label><br>
                <label id="id3"><?php echo$data['documentor1']?>[<?php echo$data['documentor1_id']?>]</label>
                <label id="id3"><?php echo$data['documentor2']?>[<?php echo$data['documentor2_id']?>]</label>
                <div id="id5" onclick="fun1()" >About..</div>
              </div>    
            </div>
          </div>
    

</body>
</html>
