<?php

$conn = mysqli_connect('localhost','root','root', 'signup');

$authenticated1 = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = strtolower($_POST['username']);
    $pass = $_POST['pass'];
    $query = "SELECT username,pass FROM student WHERE username = '$user'";
     var_dump($query);
    $result = mysqli_query($conn, $query);
    var_dump($result);
    $row = mysqli_fetch_row($result); // Fetch a row
    var_dump($row);
    if ($row) {
        if ($pass == $row[1]) {
            $authenticated1 = true;
        } else {
           
            echo "<script>alert('Invalid password!')</script>";
        }
    } else {
        echo "<script>alert('User not found')</script>";
    }
}

if ($authenticated1) {
    header("Location:/homes/stu_index.html");
    exit(); 
}
$conn->close();
?>
