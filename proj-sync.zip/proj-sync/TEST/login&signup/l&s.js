let wrapper = document.querySelector('.wrapper'),
    signUpLink = document.querySelector('.link .signup-link'),
    signInLink = document.querySelector('.link .signin-link');

signUpLink.addEventListener('click', () => {
    wrapper.classList.add('animated-signin');
    wrapper.classList.remove('animated-signup');
});

signInLink.addEventListener('click', () => {
    wrapper.classList.add('animated-signup');
    wrapper.classList.remove('animated-signin');
});

    // Function to validate the email
    function validateEmail(email) {
        const emailPattern = /^o19.*@rguktong\.ac\.in$/;
        return emailPattern.test(email);
    }

    // Function to validate the password
    function validatePassword(password) {
        // Password must contain at least one capital letter, one special character, and one number
        const passwordPattern = /^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9]).{8,}$/;
        return passwordPattern.test(password);
    }

    // Function to handle form submission
    function validateForm() {
        const username = document.querySelector('input[name="username"]').value;
        const email = document.querySelector('input[name="email"]').value;
        const password = document.querySelector('input[name="pass"]').value;
        const confirmPassword = document.querySelector('input[name="conf_passwd"]').value;

        // Perform email and password validations
        if (!validateEmail(email)) {
            alert("Email is not valid. It must start with 'o19' and end with '@rguktong.ac.in'");
            return false;
        }

        if (!validatePassword(password)) {
            alert("Password is not valid. It must contain at least one capital letter, one special character, one number, and be at least 8 characters long.");
            return false;
        }

        if (password !== confirmPassword) {
            alert("Password and Confirm Password do not match.");
            return false;
        }

        return true;
    }






    function togglePassword(inputId, icon) {
        const passwordInput = document.getElementById(inputId);
      
        if (passwordInput.type === 'password') {
          passwordInput.type = 'text';
          icon.src = 'eye-open-2-128.png'; // Replace 'eye-icon-hide.png' with your second image
        } else {
          passwordInput.type = 'password';
          icon.src = 'eye-close-1-128.png'; // Replace 'eye-icon.png' with your first image
        }
      }
      
      

    function togglePassword(inputId, icon) {
        const passwordInput = document.getElementById(inputId);
      
        if (passwordInput.type === 'password') {
          passwordInput.type = 'text';
          icon.src = 'eye-open-2-128.png'; // Replace 'eye-icon-hide.png' with your second image
        } else {
          passwordInput.type = 'password';
          icon.src = 'eye-close-1-128.png'; // Replace 'eye-icon.png' with your first image
        }
      }
      
      

