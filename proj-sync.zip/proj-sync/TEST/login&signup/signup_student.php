<?php

$servername = "localhost";
$username = "root";
$password = "root";
$databse = "user";
 $conn = mysqli_connect($servername, $username, $password,$databse);
 $go2 = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $user = $_POST['username'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$co_pass = $_POST['conf_passwd'];
 $sql = "INSERT INTO student (username,email,pass,conf_passwd) VALUES ('$user', '$email', '$pass', '$co_pass')";
 if ($conn->query($sql) === TRUE) {
 $go2 = true;
 } else {
    echo "error creating student:" . $conn->error . "<br>";
 }
 }
 
if ($go2) {
    header("Location:log&sign_student.html");
    exit(); 
}
 ?>
