<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="l&s-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Sign in & Sign up</title>
</head>

<body>

    <div class="wrapper">
        <div class="form-container sign-up">
            <form action="signup_faculty.php" method="POST" onsubmit="return validateForm()">
                <h2>sign up</h2>
                <div class="form-group">
                    <input type="text" name="username" required>
                    <label for="">username</label>
                    <i class="fas fa-user"></i>
                </div>
                <div class="form-group">
                    <input type="email" name="email" required>
                    <label for="">email</label>
                    <i class="fas fa-at"></i>
                </div>
                <div class="form-group">
                    <input type="password" name="pass" id="signupPassword" required>
                    <label for="signupPassword">Password</label>
                    <i class="fas fa-lock"></i>
                    <button type="button" class="password-toggle-button" onclick="togglePassword('signupPassword')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <div class="form-group">
                    <input type="password" name="conf_passwd" required>
                    <label for="">confirm password</label>
                    <i class="fas fa-lock"></i>
                </div>
                <button type="submit" class="btn">sign up</button>
                <div class="link">
                    <p>You already have an account?<a href="#" class="signin-link"> sign in</a></p>
                </div>
            </form>
        </div>
        <div class="form-container sign-in">
            <form action="login_faculty.php" method="POST" onsubmit="return validateForm()">
                <h2>login</h2>
                <div class="form-group">
                    <input type="text" name="username" required>
                    <i class="fas fa-user"></i>
                    <label for="">username</label>
                </div>
                 <div class="form-group">
                    <input type="password" name="pass" id="loginPassword" required>
                    <label for="loginPassword">Password</label>
                    <i class="fas fa-lock"></i>
                    <button type="button" class="password-toggle-button" onclick="togglePassword('loginPassword')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <div class="forgot-pass">
                    <a href="#">Forgot Password?</a>
                </div>
                <button type="submit" class="btn">Login</button>
                <div class="link">
                    <p>First Time? - <a href="#" class="signup-link"> Sign Up</a></p>
                </div>
            </form>
        </div>
    </div>

   <script src="https://kit.fontawesome.com/9e5ba2e3f5.js" crossorigin="anonymous"></script>
    <script src="l&s.js"></script>
</body>

</html>
